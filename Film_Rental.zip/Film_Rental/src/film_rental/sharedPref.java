/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package film_rental;


public class sharedPref {
    
     
    public  static String LoginName, model;
   
       
      
     public static void setloginname(String LoginName){
        sharedPref.LoginName = LoginName;
           
    }
    
    public static  String getLoginname(){
        return LoginName;
        
    }
   
     public static void setModel(String model){
        sharedPref.model = model;
           
    }
    
    public static  String getModel(){
        return model;
        
    }
    
    
    
    
}
